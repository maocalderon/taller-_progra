
package taller2bucles;

import java.util.Scanner;

public class ejercicio2 {

    public static void main(String[] args) {
        
    Scanner scanner = new Scanner(System.in);
        
        // Solicitar al usuario la cantidad de números a introducir
        System.out.print("Ingrese la cantidad de números a introducir: ");
        int cantidadNumeros = scanner.nextInt();
        
        // Variables para contar los números
        int mayoresCero = 0;
        int menoresCero = 0;
        int igualesCero = 0;
        
        // Ciclo para pedir los números
        for (int i = 0; i < cantidadNumeros; i++) {
            System.out.print("Ingrese el número " + (i + 1) + ": ");
            int numero = scanner.nextInt();
            
            if (numero > 0) {
                mayoresCero++;
            } else if (numero < 0) {
                menoresCero++;
            } else {
                igualesCero++;
            }
        }
        
        // Mostrar los resultados
        System.out.println("\nResultados:");
        System.out.println("Números mayores que 0: " + mayoresCero);
        System.out.println("Números menores que 0: " + menoresCero);
        System.out.println("Números iguales a 0: " + igualesCero);
        
        
        
    }
    
}
