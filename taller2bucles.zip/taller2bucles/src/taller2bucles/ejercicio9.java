
package taller2bucles;

import java.util.Scanner;

public class ejercicio9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        
        System.out.print("Ingrese la cantidad de números primos que desea mostrar: ");
        int cantidadPrimos = scanner.nextInt();
        
        
        int numerosEncontrados = 0;
        
        // Empezamos a buscar números primos desde el 2
        int numeroActual = 2;
        
        
        while (numerosEncontrados < cantidadPrimos) {
            if (esPrimo(numeroActual)) {
                System.out.print(numeroActual + " ");
                numerosEncontrados++;
            }
            numeroActual++;
        }
        
        scanner.close();
    }
    
    // Función para verificar si un número es primo
    public static boolean esPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
}
}