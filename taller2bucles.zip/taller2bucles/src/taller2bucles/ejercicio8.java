
package taller2bucles;


public class ejercicio8 {
    public static void main(String[] args) {
        int horas = 0;
        int minutos = 0;
        int segundos = 0;
        
       
        while (true) {
           
            System.out.printf("%02d:%02d:%02d%n", horas, minutos, segundos);
            
            // Esperar un segundo antes de actualizar el tiempo
            try {
                Thread.sleep(1000); // Esperar 1 segundo (1000 milisegundos)
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            
            // Actualizar los segundos
            segundos++;
            
            // Verificar si los segundos llegaron a 60 y ajustar minutos y segundos
            if (segundos == 60) {
                segundos = 0;
                minutos++;
                
                // Verificar si los minutos llegaron a 60 y ajustar horas y minutos
                if (minutos == 60) {
                    minutos = 0;
                    horas++;
                    
                    // Verificar si las horas llegaron a 24 y reiniciar el cronómetro
                    if (horas == 24) {
                        horas = 0;
                        minutos = 0;
                        segundos = 0;
                 }
                 }
                }
                }
               }
         }

