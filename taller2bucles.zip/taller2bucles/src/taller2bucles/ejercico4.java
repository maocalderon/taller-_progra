
package taller2bucles;

import java.util.Scanner;

public class ejercico4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicitar al usuario los dos números
        System.out.print("Ingrese el primer número: ");
        int numero1 = scanner.nextInt();
        
        System.out.print("Ingrese el segundo número: ");
        int numero2 = scanner.nextInt();
        
        // Determinar el número más pequeño y el más grande
        int menor = Math.min(numero1, numero2);
        int mayor = Math.max(numero1, numero2);
        
        // Imprimir todos los números pares entre el menor y el mayor
        System.out.println("Números pares entre " + menor + " y " + mayor + ":");
        for (int i = menor; i <= mayor; i++) {
            if (i % 2 == 0) {
                System.out.println(i);
            }
        }
}
}