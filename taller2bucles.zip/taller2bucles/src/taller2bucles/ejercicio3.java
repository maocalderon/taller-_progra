
package taller2bucles;

import java.util.Scanner;

public class ejercicio3 {
   public static void main(String[]args){

Scanner scanner = new Scanner(System.in);
        
        // Bucle para solicitar caracteres hasta que se introduce un espacio
        while (true) {
            // Solicitar al usuario un carácter
            System.out.print("Ingrese un carácter (o presione espacio para terminar): ");
            char caracter = scanner.next().charAt(0);
            
            // Verificar si el carácter es un espacio para terminar el programa
            if (caracter == ' ') {
                System.out.println("Programa terminado.");
                break;
            }
            
            // Verificar si el carácter es una vocal
            if (esVocal(caracter)) {
                System.out.println("VOCAL");
            } else {
                System.out.println("NO VOCAL");
            }
        }
   }
}

