
package taller2bucles;

import java.util.Scanner;

public class ejercicio6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
    
   
        System.out.print("Ingrese la base (número real): ");
        double base = scanner.nextDouble();
        
        System.out.print("Ingrese el exponente (número entero positivo): ");
        int exponente = scanner.nextInt();
   
        if (exponente < 0) {
            System.out.println("El exponente debe ser un número entero positivo.");
        } else {
            // Calcular la potencia
            double resultado = 1;
            for (int i = 0; i < exponente; i++) {
                resultado *= base;
            }
            
            // Imprimir el resultado
            System.out.println("El resultado de " + base + " elevado a la " + exponente + " es: " + resultado);
        }
}
}