
package taller2bucles;

import java.util.Scanner;

public class ejercico6 {
    
     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicitar al usuario el número de filas de la pirámide
        System.out.print("Ingrese el número de filas de la pirámide: ");
        int n = scanner.nextInt();
        
        // Imprimir la pirámide de números
        for (int i = 1; i <= n; i++) {
            // Imprimir los espacios en blanco antes de los números
            for (int j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
            
            // Imprimir los números ascendentes hasta el número actual
            for (int j = 1; j <= i; j++) {
                System.out.print(j);
            }
            
            // Imprimir los números descendentes desde el número anterior hasta 1
            for (int j = i - 1; j >= 1; j--) {
                System.out.print(j);
            }
            
            // Ir a la siguiente línea para la siguiente fila
            System.out.println();
        }
}
}