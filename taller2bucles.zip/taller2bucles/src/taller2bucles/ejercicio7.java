
package taller2bucles;


public class ejercicio7 {
    public static void main(String[] args) {
     
        int primerPago = 10;
        int meses = 20;
        
        // Calcular la razón de la progresión geométrica (doble del pago anterior)
        int razon = 2 * primerPago;
        
        // Calcular el total de lo que se pagará después de los 20 meses
        int totalPagado = primerPago * (int) Math.pow(2, meses) - primerPago;
        
        // Calcular el pago mensual promedio
        double pagoMensual = (double) totalPagado / meses;
        
        
        System.out.println("El pago mensual promedio es: " + pagoMensual + " euros.");
        System.out.println("El total de lo que pagará después de " + meses + " meses es: " + totalPagado + " euros.");
}
}