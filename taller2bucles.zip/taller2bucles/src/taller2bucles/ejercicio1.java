
package taller2bucles;
import java.util.Random;
import java.util.Scanner;

public class ejercicio1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        // Generar un número aleatorio del 1 al 100
        int numeroAdivinar = random.nextInt(100) + 1;
        
        System.out.println("¡Bienvenido al juego de adivinar un número!");
        System.out.println("El número generado está entre 1 y 100.");
        
        int intentosMaximos = 10;
        int intentosRestantes = intentosMaximos;
        
        // Bucle para solicitar los intentos del jugador
        while (intentosRestantes > 0) {
            System.out.println("\nIntentos restantes: " + intentosRestantes);
            System.out.print("Ingresa tu número: ");
            int numeroIngresado = scanner.nextInt();
            
            if (numeroIngresado == numeroAdivinar) {
                System.out.println("¡Felicidades! Has adivinado el número en " + (intentosMaximos - intentosRestantes + 1) + " intentos.");
                break;
            } else if (numeroIngresado < numeroAdivinar) {
                System.out.println("El número a adivinar es mayor.");
            } else {
                System.out.println("El número a adivinar es menor.");
            }
            
            intentosRestantes--;
        }
        
        // Mostrar el número si se agotan los intentos
        if (intentosRestantes == 0) {
            System.out.println("\nLo siento, has agotado todos tus intentos. El número era: " + numeroAdivinar);
        }
    }
}